const config = {};

// twilio config
config.twilio = {};
config.twilio.accountSid = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
config.twilio.authToken = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";

module.exports = config;